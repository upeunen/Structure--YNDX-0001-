package ru.yandex.station.media;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.util.List;

public class StationMediaTool {
    private static final String FLAG_FILE = "/data/local/tmp/voice_beep_enabled";
    private static final String STYLE_FILE = "/data/local/tmp/voice_beep_style";

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: StationMediaTool [info|seek <ms>|play|pause|beep|monitor|enable_beep <0|1>|get_beep_status|demo <1..4>|set_style <1..4>|get_style]");
            return;
        }

        String command = args[0];

        if ("beep".equalsIgnoreCase(command)) {
            int vol = getCurrentVolumePercent();
            int style = getBeepStyle();
            playStartSound(style, vol);
            System.out.println("BEEP_SUCCESS|style=" + style + "|vol=" + vol);
            return;
        }

        if ("demo".equalsIgnoreCase(command)) {
            int style = args.length > 1 ? Integer.parseInt(args[1]) : getBeepStyle();
            int vol = getCurrentVolumePercent();
            System.out.println("DEMO_START|style=" + style + "|vol=" + vol);
            playStartSound(style, vol);
            try { Thread.sleep(700); } catch (Throwable ignored) {}
            playStopSound(style, vol);
            System.out.println("DEMO_FINISHED");
            return;
        }

        if ("play_start".equalsIgnoreCase(command)) {
            int style = args.length > 1 ? Integer.parseInt(args[1]) : getBeepStyle();
            int vol = getCurrentVolumePercent();
            playStartSound(style, vol);
            System.out.println("PLAY_START_SUCCESS|style=" + style);
            return;
        }

        if ("play_stop".equalsIgnoreCase(command)) {
            int style = args.length > 1 ? Integer.parseInt(args[1]) : getBeepStyle();
            int vol = getCurrentVolumePercent();
            playStopSound(style, vol);
            System.out.println("PLAY_STOP_SUCCESS|style=" + style);
            return;
        }

        if ("set_style".equalsIgnoreCase(command)) {
            int style = args.length > 1 ? Integer.parseInt(args[1]) : 1;
            setBeepStyle(style);
            System.out.println("STYLE_SAVED:" + style);
            return;
        }

        if ("get_style".equalsIgnoreCase(command)) {
            int style = getBeepStyle();
            System.out.println("CURRENT_STYLE:" + style);
            return;
        }

        if ("monitor".equalsIgnoreCase(command)) {
            runMonitor();
            return;
        }

        if ("enable_beep".equalsIgnoreCase(command)) {
            boolean enabled = args.length > 1 && "1".equals(args[1]);
            setBeepEnabled(enabled);
            return;
        }

        if ("get_beep_status".equalsIgnoreCase(command)) {
            boolean enabled = isBeepEnabled();
            System.out.println("BEEP_STATUS:" + (enabled ? "1" : "0"));
            return;
        }

        try {
            Class<?> smClass = Class.forName("android.os.ServiceManager");
            Method getService = smClass.getMethod("getService", String.class);
            Object binder = getService.invoke(null, "media_session");
            if (binder == null) {
                System.out.println("ERROR: media_session service not found");
                return;
            }

            Class<?> stubClass = Class.forName("android.media.session.ISessionManager$Stub");
            Method asInterface = stubClass.getMethod("asInterface", Class.forName("android.os.IBinder"));
            Object sessionManager = asInterface.invoke(null, binder);

            Method getSessions = sessionManager.getClass().getMethod("getSessions", Class.forName("android.content.ComponentName"), int.class);
            List<?> sessions = (List<?>) getSessions.invoke(sessionManager, null, 0);

            if (sessions == null || sessions.isEmpty()) {
                System.out.println("NO_ACTIVE_SESSIONS");
                return;
            }

            Class<?> controllerStubClass = Class.forName("android.media.session.ISessionController$Stub");
            Method controllerAsInterface = controllerStubClass.getMethod("asInterface", Class.forName("android.os.IBinder"));

            Object activeController = null;
            String activePkg = "";

            for (Object sessionBinder : sessions) {
                Object controller = controllerAsInterface.invoke(null, sessionBinder);
                try {
                    Method getPackageName = controller.getClass().getMethod("getPackageName");
                    String pkg = (String) getPackageName.invoke(controller);
                    activeController = controller;
                    activePkg = pkg;
                    break;
                } catch (Throwable ignored) {}
            }

            if (activeController == null) {
                System.out.println("ERROR: No valid media controller found");
                return;
            }

            if ("info".equalsIgnoreCase(command)) {
                printInfo(activePkg, activeController);
            } else if ("seek".equalsIgnoreCase(command)) {
                if (args.length < 2) {
                    System.out.println("ERROR: seek requires position in ms or sec");
                    return;
                }
                long pos = Long.parseLong(args[1]);
                Method seekTo = activeController.getClass().getMethod("seekTo", long.class);
                seekTo.invoke(activeController, pos);
                System.out.println("SEEK_SUCCESS:" + pos);
                Thread.sleep(150);
                printInfo(activePkg, activeController);
            } else if ("play".equalsIgnoreCase(command)) {
                Method play = activeController.getClass().getMethod("play");
                play.invoke(activeController);
                System.out.println("PLAY_SUCCESS");
            } else if ("pause".equalsIgnoreCase(command)) {
                Method pause = activeController.getClass().getMethod("pause");
                pause.invoke(activeController);
                System.out.println("PAUSE_SUCCESS");
            } else {
                System.out.println("UNKNOWN_CMD:" + command);
            }

        } catch (Throwable t) {
            System.out.println("EXCEPTION: " + t.getMessage());
            t.printStackTrace(System.out);
        }
    }

    private static void printInfo(String pkg, Object controller) {
        try {
            long position = -1;
            int state = 0;
            float speed = 0f;
            long duration = -1;
            String title = "";
            String artist = "";

            try {
                Method getPlaybackState = controller.getClass().getMethod("getPlaybackState");
                Object ps = getPlaybackState.invoke(controller);
                if (ps != null) {
                    Method getPos = ps.getClass().getMethod("getPosition");
                    position = (Long) getPos.invoke(ps);
                    Method getState = ps.getClass().getMethod("getState");
                    state = (Integer) getState.invoke(ps);
                    Method getSpeed = ps.getClass().getMethod("getPlaybackSpeed");
                    speed = (Float) getSpeed.invoke(ps);
                }
            } catch (Throwable t) {
                // Ignore
            }

            try {
                Method getMetadata = controller.getClass().getMethod("getMetadata");
                Object md = getMetadata.invoke(controller);
                if (md != null) {
                    Method getLong = md.getClass().getMethod("getLong", String.class);
                    duration = (Long) getLong.invoke(md, "android.media.metadata.DURATION");
                    Method getString = md.getClass().getMethod("getString", String.class);
                    title = (String) getString.invoke(md, "android.media.metadata.TITLE");
                    artist = (String) getString.invoke(md, "android.media.metadata.ARTIST");
                }
            } catch (Throwable t) {
                // Ignore
            }

            System.out.println("MEDIA_INFO|pkg=" + pkg + "|state=" + state + "|pos=" + position + "|dur=" + duration + "|speed=" + speed + "|title=" + (title != null ? title : "") + "|artist=" + (artist != null ? artist : ""));
        } catch (Throwable t) {
            System.out.println("ERROR_INFO: " + t.getMessage());
        }
    }

    public static boolean isBeepEnabled() {
        File f = new File(FLAG_FILE);
        if (!f.exists()) return true;
        try {
            BufferedReader br = new BufferedReader(new FileReader(f));
            String line = br.readLine();
            br.close();
            return line == null || !line.trim().equals("0");
        } catch (Throwable t) {
            return true;
        }
    }

    public static void setBeepEnabled(boolean enabled) {
        try {
            FileWriter fw = new FileWriter(FLAG_FILE);
            fw.write(enabled ? "1\n" : "0\n");
            fw.close();
            System.out.println("BEEP_ENABLED:" + (enabled ? "1" : "0"));
        } catch (Throwable t) {
            System.out.println("ERROR: " + t.getMessage());
        }
    }

    public static int getBeepStyle() {
        File f = new File(STYLE_FILE);
        if (!f.exists()) return 1;
        try {
            BufferedReader br = new BufferedReader(new FileReader(f));
            String line = br.readLine();
            br.close();
            if (line != null) {
                int s = Integer.parseInt(line.trim());
                if (s >= 1 && s <= 4) return s;
            }
        } catch (Throwable ignored) {}
        return 1;
    }

    public static void setBeepStyle(int style) {
        try {
            FileWriter fw = new FileWriter(STYLE_FILE);
            fw.write(String.valueOf(style) + "\n");
            fw.close();
        } catch (Throwable t) {
            System.out.println("ERROR: " + t.getMessage());
        }
    }

    public static int getCurrentVolumePercent() {
        try {
            Class<?> smClass = Class.forName("android.os.ServiceManager");
            Method getService = smClass.getMethod("getService", String.class);
            Object audioBinder = getService.invoke(null, "audio");
            if (audioBinder != null) {
                Class<?> stubClass = Class.forName("android.media.IAudioService$Stub");
                Method asInterface = stubClass.getMethod("asInterface", Class.forName("android.os.IBinder"));
                Object audioService = asInterface.invoke(null, audioBinder);
                Method getStreamVolume = audioService.getClass().getMethod("getStreamVolume", int.class);
                Method getStreamMaxVolume = audioService.getClass().getMethod("getStreamMaxVolume", int.class);
                int cur = (Integer) getStreamVolume.invoke(audioService, 3); // STREAM_MUSIC = 3
                int max = (Integer) getStreamMaxVolume.invoke(audioService, 3);
                if (max > 0) {
                    return Math.max(15, Math.min(90, (int) ((cur / (float) max) * 100)));
                }
            }
        } catch (Throwable ignored) {}
        return 50;
    }

    private static void runMonitor() {
        System.out.println("VOICE_MONITOR_STARTED|log_stream_v4_start_stop");
        File logFile = new File("/sensors_cache/logs/maind.log");
        long lastStartTime = 0;
        long lastStopTime = 0;
        boolean isTransmitting = false;

        java.io.RandomAccessFile raf = null;
        try {
            if (logFile.exists()) {
                raf = new java.io.RandomAccessFile(logFile, "r");
                raf.seek(logFile.length());
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }

        while (true) {
            try {
                if (raf == null || !logFile.exists()) {
                    Thread.sleep(500);
                    if (logFile.exists()) {
                        try {
                            if (raf != null) raf.close();
                            raf = new java.io.RandomAccessFile(logFile, "r");
                            raf.seek(logFile.length());
                        } catch (Throwable ignored) {}
                    }
                    continue;
                }

                long currentLen = logFile.length();
                if (currentLen < raf.getFilePointer()) {
                    try {
                        raf.close();
                        raf = new java.io.RandomAccessFile(logFile, "r");
                    } catch (Throwable ignored) {}
                }

                String line = raf.readLine();
                if (line == null) {
                    Thread.sleep(50);
                    continue;
                }

                long now = System.currentTimeMillis();

                // 1. Детекция начала передачи (микрофон включился и захватывает голос)
                if (line.contains("onStartVoiceInput header = Vins.VoiceInput") || line.contains("onAliceStateChanged: LISTENING")) {
                    if ((now - lastStartTime) > 2500) {
                        lastStartTime = now;
                        isTransmitting = true;
                        if (isBeepEnabled()) {
                            int vol = getCurrentVolumePercent();
                            int style = getBeepStyle();
                            System.out.println("VOICE_START_DETECTED|style=" + style + "|vol=" + vol);
                            playStartSound(style, vol);
                        }
                    }
                }

                // 2. Детекция завершения передачи (микрофон остановлен, передача завершена)
                if (line.contains("Stop AudioStream") || line.contains("onAliceStateChanged: IDLE") || line.contains("onAliceStateChanged: SPEAKING")) {
                    if (isTransmitting && (now - lastStartTime) > 400 && (now - lastStopTime) > 2000) {
                        lastStopTime = now;
                        isTransmitting = false;
                        if (isBeepEnabled()) {
                            int vol = getCurrentVolumePercent();
                            int style = getBeepStyle();
                            System.out.println("VOICE_STOP_DETECTED|style=" + style + "|vol=" + vol);
                            playStopSound(style, vol);
                        }
                    }
                }

            } catch (Throwable t) {
                try {
                    Thread.sleep(500);
                } catch (Throwable ignored) {}
            }
        }
    }

    // --- Генерация и воспроизведение звуков ---

    public static void playStartSound(int style, int volumePercent) {
        float gain = (volumePercent / 100.0f);
        short[] samples;
        int rate = 44100;

        switch (style) {
            case 2: // Двухтоновый перелив вверх (Ми -> Ля)
                short[] n1 = genTone(659.2, 45, gain, rate);
                short[] n2 = genTone(880.0, 55, gain, rate);
                samples = concat(n1, n2);
                break;
            case 3: // Рация / клик-пик (До 1046 Гц)
                samples = genTone(1046.5, 38, gain * 1.1f, rate);
                break;
            case 4: // Ультра-мягкий клик
                samples = genTone(720.0, 28, gain * 0.75f, rate);
                break;
            case 1: // Тональный чистый (нота Ля 880 Гц)
            default:
                samples = genTone(880.0, 75, gain, rate);
                break;
        }

        playPcm(samples, rate);
    }

    public static void playStopSound(int style, int volumePercent) {
        float gain = (volumePercent / 100.0f);
        short[] samples;
        int rate = 44100;

        switch (style) {
            case 2: // Двухтоновый перелив вниз (Ля -> Ми)
                short[] n1 = genTone(880.0, 45, gain, rate);
                short[] n2 = genTone(659.2, 60, gain, rate);
                samples = concat(n1, n2);
                break;
            case 3: // Roger-beep (двойной микро-сигнал 523 Гц)
                short[] r1 = genTone(523.2, 30, gain * 0.9f, rate);
                short[] silence = new short[(int)(0.025 * rate)];
                short[] r2 = genTone(523.2, 35, gain * 0.9f, rate);
                samples = concat(concat(r1, silence), r2);
                break;
            case 4: // Ультра-мягкий низкий клик
                samples = genTone(360.0, 32, gain * 0.75f, rate);
                break;
            case 1: // Тональный мягкий спад (нота Ре 587 Гц)
            default:
                samples = genTone(587.3, 85, gain, rate);
                break;
        }

        playPcm(samples, rate);
    }

    private static short[] genTone(double freq, int durationMs, float gain, int sampleRate) {
        int n = (durationMs * sampleRate) / 1000;
        short[] buf = new short[n];
        int attack = Math.min(n / 4, (12 * sampleRate) / 1000);
        int decay = Math.min(n / 2, (25 * sampleRate) / 1000);
        
        // Базовая амплитуда снижена с 32000 до 13500 для комфортной мягкой громкости (тише более чем в 2 раза)
        double amp = 13500.0 * gain;

        for (int i = 0; i < n; i++) {
            double env = 1.0;
            if (i < attack) {
                env = (double) i / attack;
            } else if (i > n - decay) {
                env = (double) (n - i) / decay;
            }
            double sinVal = Math.sin(2.0 * Math.PI * i / (sampleRate / freq));
            buf[i] = (short) (sinVal * amp * env);
        }
        return buf;
    }

    private static short[] concat(short[] a, short[] b) {
        short[] res = new short[a.length + b.length];
        System.arraycopy(a, 0, res, 0, a.length);
        System.arraycopy(b, 0, res, a.length, b.length);
        return res;
    }

    private static void playPcm(short[] sample, int sampleRate) {
        try {
            android.media.AudioTrack audioTrack = new android.media.AudioTrack(
                android.media.AudioManager.STREAM_NOTIFICATION,
                sampleRate,
                android.media.AudioFormat.CHANNEL_OUT_MONO,
                android.media.AudioFormat.ENCODING_PCM_16BIT,
                sample.length * 2,
                android.media.AudioTrack.MODE_STATIC
            );
            audioTrack.write(sample, 0, sample.length);
            audioTrack.play();
            Thread.sleep(Math.max(50, (sample.length * 1000) / sampleRate + 25));
            audioTrack.stop();
            audioTrack.release();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
