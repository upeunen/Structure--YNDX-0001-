﻿# 1. Останавливаем VLC
& "d:\Pult\run_adb_cmd.ps1" -Command "am force-stop org.videolan.vlc"
Start-Sleep -Milliseconds 500

# 2. Записываем чистые настройки
& "d:\Pult\write_clean_xml.ps1"
Start-Sleep -Milliseconds 500

# 3. Запускаем видео
$streamUrl = "http://127.0.0.1:8090/api/stream/dfc2b366d4bbb436716263fe585a55165c46a470/2"
$startCmd = "am start -a android.intent.action.VIEW -d '$streamUrl' -t 'video/*' -n 'org.videolan.vlc/org.videolan.vlc.gui.video.VideoPlayerActivity'"
& "d:\Pult\run_adb_cmd.ps1" -Command $startCmd

Write-Output "APPLIED_AND_RESTARTED"
