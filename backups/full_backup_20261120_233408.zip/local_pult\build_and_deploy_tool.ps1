﻿$tempDir = "C:\Users\DAE\AppData\Local\Temp\station_media"
if (Test-Path $tempDir) { Remove-Item -Recurse -Force $tempDir }
$srcDir = "$tempDir\src\ru\yandex\station\media"
New-Item -ItemType Directory -Force -Path $srcDir | Out-Null
$binDir = "$tempDir\bin"
New-Item -ItemType Directory -Force -Path $binDir | Out-Null

Copy-Item "D:\Pult\StationMediaTool.java" "$srcDir\StationMediaTool.java"

& "C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot\bin\javac.exe" -source 1.8 -target 1.8 -cp "C:\Users\DAE\AppData\Local\Android\Sdk\platforms\android-36\android.jar" -d $binDir "$srcDir\StationMediaTool.java"
& "C:\Users\DAE\AppData\Local\Android\Sdk\build-tools\36.1.0\d8.bat" --min-api 21 --output $binDir "$binDir\ru\yandex\station\media\StationMediaTool.class"

$dexPath = "$binDir\classes.dex"
if (-not (Test-Path $dexPath)) {
    Write-Host "Failed to build dex"
    exit 1
}

$bytes = [System.IO.File]::ReadAllBytes($dexPath)
Write-Host "Dex size: $($bytes.Length) bytes"

$assetsDir = "D:\Pult\app\src\main\assets"
if (-not (Test-Path $assetsDir)) { New-Item -ItemType Directory -Force -Path $assetsDir | Out-Null }
Copy-Item $dexPath "$assetsDir\station_media.dex" -Force

& powershell -ExecutionPolicy Bypass -File .\upload_file.ps1 -LocalFile $dexPath -RemoteFile "/data/local/tmp/station_media.dex"

& powershell -ExecutionPolicy Bypass -File .\run_adb_cmd.ps1 "CLASSPATH=/data/local/tmp/station_media.dex app_process /data/local/tmp ru.yandex.station.media.StationMediaTool info"
