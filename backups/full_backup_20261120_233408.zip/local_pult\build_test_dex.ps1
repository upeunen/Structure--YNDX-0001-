$tempDir = "C:\Users\DAE\AppData\Local\Temp\mediatool"
if (Test-Path $tempDir) { Remove-Item -Recurse -Force $tempDir }
$srcDir = "$tempDir\src\ru\yandex\station\media"
New-Item -ItemType Directory -Force -Path $srcDir | Out-Null
$binDir = "$tempDir\bin"
New-Item -ItemType Directory -Force -Path $binDir | Out-Null

$javaCode = @"
package ru.yandex.station.media;
public class MediaTool {
    public static void main(String[] args) {
        System.out.println("HELLO_MEDIA_TOOL_OK");
    }
}
"@
[System.IO.File]::WriteAllText("$srcDir\MediaTool.java", $javaCode, [System.Text.Encoding]::ASCII)

& "C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot\bin\javac.exe" -source 1.8 -target 1.8 -d $binDir "$srcDir\MediaTool.java"
& "C:\Users\DAE\AppData\Local\Android\Sdk\build-tools\36.1.0\d8.bat" --output $binDir "$binDir\ru\yandex\station\media\MediaTool.class"

if (Test-Path "$binDir\classes.dex") {
    Write-Host "SUCCESS: classes.dex generated!"
} else {
    Write-Host "FAILED to generate classes.dex"
}
