$bytes = [System.IO.File]::ReadAllBytes('C:\Users\DAE\AppData\Local\Temp\mediatool\bin\classes.dex')
$b64 = [Convert]::ToBase64String($bytes)
$cmd = "echo '$b64' | toybox base64 -d > /data/local/tmp/mediatool.dex && CLASSPATH=/data/local/tmp/mediatool.dex app_process /data/local/tmp ru.yandex.station.media.MediaTool"
& powershell -ExecutionPolicy Bypass -File .\run_adb_cmd.ps1 $cmd
