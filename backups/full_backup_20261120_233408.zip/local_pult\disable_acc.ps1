& "d:\Pult\run_adb_cmd.ps1" -Command "settings put secure enabled_accessibility_services ''"
& "d:\Pult\run_adb_cmd.ps1" -Command "settings put secure accessibility_enabled 0"
Write-Output "ACCESSIBILITY_DISABLED"
