﻿try {
    $client = New-Object System.Net.Sockets.TcpClient
    $client.Connect("192.168.100.6", 5555)
    $stream = $client.GetStream()
    $stream.ReadTimeout = 10000

    function Write-AdbMsg($cmd, $a0, $a1, [byte[]]$data) {
        $sum = 0
        if ($data) { foreach ($b in $data) { $sum += [int]$b -band 0xFF } }
        $len = if ($data) { $data.Length } else { 0 }
        $magic = ($cmd -bxor 0xFFFFFFFF)
        $hdr = New-Object byte[] 24
        [System.BitConverter]::GetBytes([int]$cmd).CopyTo($hdr, 0)
        [System.BitConverter]::GetBytes([int]$a0).CopyTo($hdr, 4)
        [System.BitConverter]::GetBytes([int]$a1).CopyTo($hdr, 8)
        [System.BitConverter]::GetBytes([int]$len).CopyTo($hdr, 12)
        [System.BitConverter]::GetBytes([int]$sum).CopyTo($hdr, 16)
        [System.BitConverter]::GetBytes([int]$magic).CopyTo($hdr, 20)
        $stream.Write($hdr, 0, 24)
        if ($len -gt 0) { $stream.Write($data, 0, $len) }
        $stream.Flush()
    }

    function Read-AdbMsg() {
        $hdr = New-Object byte[] 24
        $r = 0
        while ($r -lt 24) {
            $n = $stream.Read($hdr, $r, 24 - $r)
            if ($n -le 0) { break }
            $r += $n
        }
        if ($r -lt 24) { return $null }
        $cmd = [System.BitConverter]::ToInt32($hdr, 0)
        $a0 = [System.BitConverter]::ToInt32($hdr, 4)
        $a1 = [System.BitConverter]::ToInt32($hdr, 8)
        $len = [System.BitConverter]::ToInt32($hdr, 12)
        $data = New-Object byte[] $len
        $dr = 0
        while ($dr -lt $len) {
            $n = $stream.Read($data, $dr, $len - $dr)
            if ($n -le 0) { break }
            $dr += $n
        }
        return @{ Cmd = $cmd; Arg0 = $a0; Arg1 = $a1; Data = $data }
    }

    $cnxn = [System.Text.Encoding]::UTF8.GetBytes("host::`0")
    Write-AdbMsg 0x4e584e43 0x01000000 4096 $cnxn
    $resp = Read-AdbMsg

    $cmdStr = "shell:base64 /data/local/tmp/vlc_screen.png`0"
    $shellCmd = [System.Text.Encoding]::UTF8.GetBytes($cmdStr)
    Write-AdbMsg 0x4e45504f 1 0 $shellCmd
    $openResp = Read-AdbMsg
    $remoteId = $openResp.Arg0

    $b64 = New-Object System.Text.StringBuilder
    while ($true) {
        $msg = Read-AdbMsg
        if (-not $msg) { break }
        if ($msg.Cmd -eq 0x45545257) {
            $b64.Append([System.Text.Encoding]::ASCII.GetString($msg.Data)) | Out-Null
            Write-AdbMsg 0x59414b4f 1 $remoteId $null
        } elseif ($msg.Cmd -eq 0x45534c43) {
            break
        }
    }
    $client.Close()
    
    $cleanB64 = [System.Text.RegularExpressions.Regex]::Replace($b64.ToString(), '[^A-Za-z0-9+/=]', '')
    $bytes = [System.Convert]::FromBase64String($cleanB64)
    $dest = "C:\Users\DAE\.gemini\antigravity\brain\25a2d3df-ce0c-49cf-92c4-eb551cf66901\tv_screen.png"
    [System.IO.File]::WriteAllBytes($dest, $bytes)
    "FILE_SAVED: " + $bytes.Length
} catch {
    "ERR: " + $_.Exception.Message
}

