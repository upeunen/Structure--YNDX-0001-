$tempDir = "C:\Users\DAE\AppData\Local\Temp\mediatool"
$srcDir = "$tempDir\src\ru\yandex\station\media"
$binDir = "$tempDir\bin"

$javaCode = @"
package ru.yandex.station.media;

import java.lang.reflect.Method;

public class MediaTool {
    public static void main(String[] args) {
        try {
            Class<?> smClass = Class.forName("android.os.ServiceManager");
            Method getService = smClass.getMethod("getService", String.class);
            Object binder = getService.invoke(null, "media_session");
            System.out.println("Binder: " + binder);

            Class<?> stubClass = Class.forName("android.media.session.ISessionManager`$Stub");
            Method asInterface = stubClass.getMethod("asInterface", Class.forName("android.os.IBinder"));
            Object sessionManager = asInterface.invoke(null, binder);
            System.out.println("SessionManager: " + sessionManager);

            System.out.println("--- ISessionManager Methods ---");
            for (Method m : sessionManager.getClass().getMethods()) {
                if (m.getDeclaringClass() != Object.class) {
                    System.out.println(m.getName() + "(" + java.util.Arrays.toString(m.getParameterTypes()) + ") -> " + m.getReturnType().getName());
                }
            }
        } catch (Throwable t) {
            t.printStackTrace(System.out);
        }
    }
}
"@
[System.IO.File]::WriteAllText("$srcDir\MediaTool.java", $javaCode, [System.Text.Encoding]::ASCII)

& "C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot\bin\javac.exe" -source 1.8 -target 1.8 -cp "C:\Users\DAE\AppData\Local\Android\Sdk\platforms\android-36\android.jar" -d $binDir "$srcDir\MediaTool.java"
& "C:\Users\DAE\AppData\Local\Android\Sdk\build-tools\36.1.0\d8.bat" --output $binDir "$binDir\ru\yandex\station\media\MediaTool.class"

$bytes = [System.IO.File]::ReadAllBytes("$binDir\classes.dex")
$b64 = [Convert]::ToBase64String($bytes)
$cmd = "echo '$b64' | toybox base64 -d > /data/local/tmp/mediatool.dex && CLASSPATH=/data/local/tmp/mediatool.dex app_process /data/local/tmp ru.yandex.station.media.MediaTool"
& powershell -ExecutionPolicy Bypass -File .\run_adb_cmd.ps1 $cmd
