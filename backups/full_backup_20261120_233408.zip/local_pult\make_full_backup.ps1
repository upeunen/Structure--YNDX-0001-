﻿# Скрипт создания полного резервного копирования проекта и Яндекс.Станции
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = "d:\Pult\backups\full_backup_$timestamp"
$stationBackupDir = "$backupDir\station_data"
$localBackupDir = "$backupDir\local_pult"

Write-Host "=== Начало создания полного резервного копирования [$timestamp] ===" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $stationBackupDir | Out-Null
New-Item -ItemType Directory -Force -Path $localBackupDir | Out-Null

# 1. Локальный бэкап исходников и скриптов Пульта
Write-Host "[1/3] Резервное копирование локальных файлов проекта Пульт..." -ForegroundColor Yellow
$excludeDirs = @('.gradle', 'build', '.kotlin', 'backups')
Get-ChildItem -Path "d:\Pult" | ForEach-Object {
    if ($excludeDirs -notcontains $_.Name) {
        Copy-Item -Path $_.FullName -Destination $localBackupDir -Recurse -Force
    }
}
Write-Host "-> Локальные файлы скопированы в $localBackupDir" -ForegroundColor Green

# 2. Функция для скачивания файлов со Станции в Base64
function Download-StationFile($remotePath, $localDest) {
    try {
        $cmd = "su 0 sh -c '/system/bin/busybox-smp base64 $remotePath 2>/dev/null'"
        $out = powershell -ExecutionPolicy Bypass -File "d:\Pult\run_adb_cmd.ps1" -Command $cmd -TimeoutMs 15000
        if ($out) {
            $cleanB64 = ($out -join "").Trim()
            if ($cleanB64.Length -gt 0) {
                $bytes = [System.Convert]::FromBase64String($cleanB64)
                [System.IO.File]::WriteAllBytes($localDest, $bytes)
                Write-Host "   + Скачан: $remotePath ($($bytes.Length) байт)" -ForegroundColor Gray
                return $true
            }
        }
    } catch {
        Write-Host "   ! Ошибка при скачивании $($remotePath): $_" -ForegroundColor Red
    }
    return $false
}

# 3. Скачивание критических файлов со Станции
Write-Host "[2/3] Выгрузка конфигураций и скриптов с Яндекс.Станции..." -ForegroundColor Yellow

$filesToDownload = @(
    "/data/local/bin/userinit.sh",
    "/data/local/bin/voice_beep_service.sh",
    "/data/local/bin/torrserver_service.sh",
    "/data/local/bin/web_server.sh",
    "/data/local/bin/torrproxy.sh",
    "/data/local/bin/voice_launcher.sh",
    "/data/local/bin/wake_kodi.sh",
    "/data/local/bin/wol_listener.sh",
    "/data/local/bin/kodi_watchdog.sh",
    "/data/torrserver/config.yaml",
    "/data/local/tmp/station_media.dex",
    "/data/local/tmp/voice_beep_enabled",
    "/data/local/tmp/voice_beep_style"
)

foreach ($f in $filesToDownload) {
    $fname = [System.IO.Path]::GetFileName($f)
    Download-StationFile $f "$stationBackupDir\$fname"
}

# 4. Скачивание среза логов Алисы (последние 200 КБ) для анализа голосовых команд
Write-Host "[3/3] Сохранение текущего среза логов Алисы для анализа..." -ForegroundColor Yellow
$logCmd = "su 0 sh -c 'tail -n 2000 /sensors_cache/logs/maind.log | /system/bin/busybox-smp base64'"
$logOut = powershell -ExecutionPolicy Bypass -File "d:\Pult\run_adb_cmd.ps1" -Command $logCmd -TimeoutMs 15000
if ($logOut) {
    $cleanLogB64 = ($logOut -join "").Trim()
    if ($cleanLogB64.Length -gt 0) {
        $logBytes = [System.Convert]::FromBase64String($cleanLogB64)
        [System.IO.File]::WriteAllBytes("$stationBackupDir\maind_alice_recent.log", $logBytes)
        Write-Host "   + Лог Алисы сохранен: maind_alice_recent.log ($($logBytes.Length) байт)" -ForegroundColor Gray
    }
}

# 5. Упаковка в единый ZIP-архив
$zipPath = "d:\Pult\backups\full_backup_$timestamp.zip"
Compress-Archive -Path "$backupDir\*" -DestinationPath $zipPath -Force
Write-Host "`n=== ПОЛНЫЙ БЭКАП УСПЕШНО СОЗДАН! ===" -ForegroundColor Green
Write-Host "Папка бэкапа: $backupDir" -ForegroundColor Cyan
Write-Host "ZIP-архив:    $zipPath" -ForegroundColor Cyan
