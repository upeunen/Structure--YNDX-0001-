﻿$bytes = [System.IO.File]::ReadAllBytes('d:\Pult\station_media.dex')
$b64 = [System.Convert]::ToBase64String($bytes)
Write-Host "Base64 length: $($b64.Length)"

# Очистим b64 на колонке
powershell -ExecutionPolicy Bypass -File "d:\Pult\run_adb_cmd.ps1" -Command "rm -f /data/local/tmp/station_media.b64"

# Передадим чанками по 2000 символов
$chunkSize = 2000
for ($i = 0; $i -lt $b64.Length; $i += $chunkSize) {
    $len = [Math]::Min($chunkSize, $b64.Length - $i)
    $part = $b64.Substring($i, $len)
    powershell -ExecutionPolicy Bypass -File "d:\Pult\run_adb_cmd.ps1" -Command "echo -n '$part' >> /data/local/tmp/station_media.b64"
}

# Декодируем и проверим размер
powershell -ExecutionPolicy Bypass -File "d:\Pult\run_adb_cmd.ps1" -Command "/system/bin/busybox-smp base64 -d /data/local/tmp/station_media.b64 > /data/local/tmp/station_media.dex; ls -l /data/local/tmp/station_media.dex; rm -f /data/local/tmp/station_media.b64"
