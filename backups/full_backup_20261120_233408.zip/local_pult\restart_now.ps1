& "d:\Pult\run_adb_cmd.ps1" -Command "am force-stop org.videolan.vlc"
Start-Sleep -Milliseconds 400
$streamUrl = "http://127.0.0.1:8090/api/stream/dfc2b366d4bbb436716263fe585a55165c46a470/2"
$startCmd = "am start -n org.videolan.vlc/.StartActivity -a android.intent.action.VIEW -d '$streamUrl' -t 'video/*' --ei position 138000"
& "d:\Pult\run_adb_cmd.ps1" -Command $startCmd
Write-Output "RESTARTED_CLEANLY"
