﻿$lines = @(
'<?xml version=''1.0'' encoding=''utf-8'' standalone=''yes'' ?>',
'<map>',
'    <boolean name="navigator_screen_unstable" value="true" />',
'    <boolean name="last_session_crashed" value="false" />',
'    <int name="first_run" value="3060500" />',
'    <int name="position_in_media_list" value="0" />',
'    <string name="last_whats_new">3.6</string>',
'    <float name="VideoSpeed" value="1.0" />',
'    <boolean name="app_onboarding_done" value="true" />',
'    <boolean name="media_shuffling" value="false" />',
'    <boolean name="pref_show_video_settings_disclaimer" value="false" />',
'    <string name="app_theme">0</string>',
'    <boolean name="widget_migration_key" value="true" />',
'    <int name="current_settings_version" value="15" />',
'    <int name="key_current_major_version" value="3" />',
'    <long name="VideoResumeTime" value="-1" />',
'    <int name="ml_scan" value="1" />',
'    <int name="fragment_id" value="2131362810" />',
'    <boolean name="video_player_tips_shown" value="true" />',
'    <int name="audio_stop_after" value="-1" />',
'    <int name="video_hud_timeout_in_s" value="2" />',
'    <boolean name="enable_double_tap_seek" value="false" />',
'    <boolean name="enable_seek_buttons" value="false" />',
'    <boolean name="enable_volume_gesture" value="false" />',
'    <boolean name="enable_brightness_gesture" value="false" />',
'</map>'
)

# 1. Принудительно останавливаем VLC
& "d:\Pult\run_adb_cmd.ps1" -Command "am force-stop org.videolan.vlc"
Start-Sleep -Milliseconds 500

# 2. Очищаем файл и построчно пишем на ТВ
& "d:\Pult\run_adb_cmd.ps1" -Command "rm -f /sdcard/vlc_prefs_new.xml"
foreach ($line in $lines) {
    $escaped = $line.Replace('"', '\"')
    & "d:\Pult\run_adb_cmd.ps1" -Command "echo `"$escaped`" >> /sdcard/vlc_prefs_new.xml"
}

# 3. Копируем в shared_prefs от имени пользователя приложения
& "d:\Pult\run_adb_cmd.ps1" -Command "su 10026 cp /sdcard/vlc_prefs_new.xml /data/data/org.videolan.vlc/shared_prefs/org.videolan.vlc_preferences.xml && su 10026 chmod 660 /data/data/org.videolan.vlc/shared_prefs/org.videolan.vlc_preferences.xml"

# 4. Проверяем содержимое
$check = & "d:\Pult\run_adb_cmd.ps1" -Command "su 10026 tail -n 6 /data/data/org.videolan.vlc/shared_prefs/org.videolan.vlc_preferences.xml"
Write-Output "VERIFICATION:"
Write-Output $check

# 5. Перезапускаем видео
$streamUrl = "http://127.0.0.1:8090/api/stream/dfc2b366d4bbb436716263fe585a55165c46a470/2"
$startCmd = "am start -a android.intent.action.VIEW -d '$streamUrl' -t 'video/*' -n 'org.videolan.vlc/org.videolan.vlc.gui.video.VideoPlayerActivity'"
& "d:\Pult\run_adb_cmd.ps1" -Command $startCmd
