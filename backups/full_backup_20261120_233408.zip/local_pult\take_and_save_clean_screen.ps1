﻿try {
    $client = New-Object System.Net.Sockets.TcpClient
    $client.Connect("192.168.100.6", 5555)
    $stream = $client.GetStream()
    $stream.ReadTimeout = 15000

    function Write-AdbMsg($cmd, $a0, $a1, [byte[]]$data) {
        $sum = 0
        if ($data) { foreach ($b in $data) { $sum += [int]$b -band 0xFF } }
        $len = if ($data) { $data.Length } else { 0 }
        $magic = ($cmd -bxor 0xFFFFFFFF)
        $hdr = New-Object byte[] 24
        [System.BitConverter]::GetBytes([int]$cmd).CopyTo($hdr, 0)
        [System.BitConverter]::GetBytes([int]$a0).CopyTo($hdr, 4)
        [System.BitConverter]::GetBytes([int]$a1).CopyTo($hdr, 8)
        [System.BitConverter]::GetBytes([int]$len).CopyTo($hdr, 12)
        [System.BitConverter]::GetBytes([int]$sum).CopyTo($hdr, 16)
        [System.BitConverter]::GetBytes([int]$magic).CopyTo($hdr, 20)
        $stream.Write($hdr, 0, 24)
        if ($len -gt 0) { $stream.Write($data, 0, $len) }
        $stream.Flush()
    }

    function Read-AdbMsg() {
        $hdr = New-Object byte[] 24
        $r = 0
        while ($r -lt 24) {
            $n = $stream.Read($hdr, $r, 24 - $r)
            if ($n -le 0) { break }
            $r += $n
        }
        if ($r -lt 24) { return $null }
        $cmd = [System.BitConverter]::ToInt32($hdr, 0)
        $a0 = [System.BitConverter]::ToInt32($hdr, 4)
        $a1 = [System.BitConverter]::ToInt32($hdr, 8)
        $len = [System.BitConverter]::ToInt32($hdr, 12)
        $data = New-Object byte[] $len
        $dr = 0
        while ($dr -lt $len) {
            $n = $stream.Read($data, $dr, $len - $dr)
            if ($n -le 0) { break }
            $dr += $n
        }
        return @{ Cmd = $cmd; Arg0 = $a0; Arg1 = $a1; Data = $data }
    }

    $cnxn = [System.Text.Encoding]::UTF8.GetBytes("host::`0")
    Write-AdbMsg 0x4e584e43 0x01000000 4096 $cnxn
    $resp = Read-AdbMsg

    # Сначала сделаем screencap на устройство
    $cmdCap = [System.Text.Encoding]::UTF8.GetBytes("shell:screencap -p /data/local/tmp/sc.png`0")
    Write-AdbMsg 0x4e45504f 1 0 $cmdCap
    $openCap = Read-AdbMsg
    $capId = $openCap.Arg0
    while ($true) {
        $msg = Read-AdbMsg; if (-not $msg) { break }
        if ($msg.Cmd -eq 0x45545257) { Write-AdbMsg 0x59414b4f 1 $capId $null }
        elseif ($msg.Cmd -eq 0x45534c43) { break }
    }

    # Теперь скачаем через exec:cat (в exec нет pty и перевода 0x0A в 0x0D 0x0A!)
    $cmdCat = [System.Text.Encoding]::UTF8.GetBytes("exec:cat /data/local/tmp/sc.png`0")
    Write-AdbMsg 0x4e45504f 2 0 $cmdCat
    $openCat = Read-AdbMsg
    $catId = $openCat.Arg0

    $destPath = "C:\Users\DAE\.gemini\antigravity\brain\0e8720fe-36e6-4a63-bdd9-ddcd523e2ec6\tv_clean.png"
    $fs = [System.IO.File]::Create($destPath)
    while ($true) {
        $msg = Read-AdbMsg; if (-not $msg) { break }
        if ($msg.Cmd -eq 0x45545257) {
            $fs.Write($msg.Data, 0, $msg.Data.Length)
            Write-AdbMsg 0x59414b4f 2 $catId $null
        } elseif ($msg.Cmd -eq 0x45534c43) { break }
    }
    $fs.Close()
    $client.Close()
    $fi = Get-Item $destPath
    Write-Output "SUCCESS: $($fi.Length) bytes"
} catch {
    Write-Output "ERR: $($_.Exception.Message)"
}
