﻿try {
    $client = New-Object System.Net.Sockets.TcpClient
    $client.Connect("192.168.100.6", 5555)
    $stream = $client.GetStream()
    $stream.ReadTimeout = 4000

    function Write-AdbMsg($cmd, $a0, $a1, [byte[]]$data) {
        $sum = 0; if ($data) { foreach ($b in $data) { $sum += [int]$b -band 0xFF } }
        $len = if ($data) { $data.Length } else { 0 }
        $magic = ($cmd -bxor 0xFFFFFFFF)
        $hdr = New-Object byte[] 24
        [System.BitConverter]::GetBytes([int]$cmd).CopyTo($hdr, 0)
        [System.BitConverter]::GetBytes([int]$a0).CopyTo($hdr, 4)
        [System.BitConverter]::GetBytes([int]$a1).CopyTo($hdr, 8)
        [System.BitConverter]::GetBytes([int]$len).CopyTo($hdr, 12)
        [System.BitConverter]::GetBytes([int]$sum).CopyTo($hdr, 16)
        [System.BitConverter]::GetBytes([int]$magic).CopyTo($hdr, 20)
        $stream.Write($hdr, 0, 24); if ($len -gt 0) { $stream.Write($data, 0, $len) }; $stream.Flush()
    }
    function Read-AdbMsg() {
        $hdr = New-Object byte[] 24; $r = 0
        while ($r -lt 24) { $n = $stream.Read($hdr, $r, 24 - $r); if ($n -le 0) { break }; $r += $n }
        if ($r -lt 24) { return $null }
        $cmd = [System.BitConverter]::ToInt32($hdr, 0)
        $a0 = [System.BitConverter]::ToInt32($hdr, 4); $a1 = [System.BitConverter]::ToInt32($hdr, 8)
        $len = [System.BitConverter]::ToInt32($hdr, 12); $data = New-Object byte[] $len; $dr = 0
        while ($dr -lt $len) { $n = $stream.Read($data, $dr, $len - $dr); if ($n -le 0) { break }; $dr += $n }
        return @{ Cmd = $cmd; Arg0 = $a0; Arg1 = $a1; Data = $data }
    }
    $cnxn = [System.Text.Encoding]::UTF8.GetBytes("host::`0")
    Write-AdbMsg 0x4e584e43 0x01000000 4096 $cnxn
    $resp = Read-AdbMsg

    # Кликаем точно в кнопку ПРОПУСТИТЬ (x=1730, y=960)
    $cmdStr = "shell:input tap 1730 960`0"
    Write-AdbMsg 0x4e45504f 1 0 ([System.Text.Encoding]::UTF8.GetBytes($cmdStr))
    $openResp = Read-AdbMsg
    $remoteId = $openResp.Arg0

    while ($true) {
        $msg = Read-AdbMsg; if (-not $msg) { break }
        if ($msg.Cmd -eq 0x45545257) {
            Write-AdbMsg 0x59414b4f 1 $remoteId $null
        } elseif ($msg.Cmd -eq 0x45534c43) { break }
    }
    $client.Close()
    "SKIP_TAPPED"
} catch { $_.Exception.Message }
