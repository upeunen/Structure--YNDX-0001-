$raw = & powershell -ExecutionPolicy Bypass -File .\run_adb_cmd.ps1 "su 0 /system/bin/sh -c 'CLASSPATH=/data/local/tmp/station_media.dex app_process /data/local/tmp ru.yandex.station.media.StationMediaTool info'"
$infoStr = $raw -join "`n"
Write-Host "Current info: $infoStr"

if ($infoStr -match 'pos=(\d+)') {
    $currentPos = [long]$Matches[1]
    $newPos = $currentPos + 300000
    Write-Host "Current pos: $currentPos ms. Seeking to: $newPos ms (+5 min)..."
    $seekRes = & powershell -ExecutionPolicy Bypass -File .\run_adb_cmd.ps1 "su 0 /system/bin/sh -c 'CLASSPATH=/data/local/tmp/station_media.dex app_process /data/local/tmp ru.yandex.station.media.StationMediaTool seek $newPos'"
    Write-Host "Result: $seekRes"
}
