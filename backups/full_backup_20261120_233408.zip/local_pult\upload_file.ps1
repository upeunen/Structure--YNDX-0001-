param(
    [string]$LocalFile,
    [string]$RemoteFile
)

$bytes = [System.IO.File]::ReadAllBytes($LocalFile)
$b64 = [Convert]::ToBase64String($bytes)

$tmpB64 = "/data/local/tmp/upload.b64"
& powershell -ExecutionPolicy Bypass -File .\run_adb_cmd.ps1 "rm -f $tmpB64 $RemoteFile"

$chunkSize = 1000
for ($i = 0; $i -lt $b64.Length; $i += $chunkSize) {
    $len = [Math]::Min($chunkSize, $b64.Length - $i)
    $part = $b64.Substring($i, $len)
    & powershell -ExecutionPolicy Bypass -File .\run_adb_cmd.ps1 "printf '%s' '$part' >> $tmpB64"
}

& powershell -ExecutionPolicy Bypass -File .\run_adb_cmd.ps1 "toybox base64 -d $tmpB64 > $RemoteFile && rm -f $tmpB64 && ls -la $RemoteFile"
