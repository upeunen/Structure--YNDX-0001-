﻿$xmlContent = @"
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <boolean name="navigator_screen_unstable" value="true" />
    <boolean name="last_session_crashed" value="false" />
    <int name="first_run" value="3060500" />
    <int name="position_in_media_list" value="0" />
    <string name="last_whats_new">3.6</string>
    <float name="VideoSpeed" value="1.0" />
    <boolean name="app_onboarding_done" value="true" />
    <boolean name="media_shuffling" value="false" />
    <boolean name="pref_show_video_settings_disclaimer" value="false" />
    <string name="app_theme">0</string>
    <boolean name="widget_migration_key" value="true" />
    <int name="current_settings_version" value="15" />
    <int name="key_current_major_version" value="3" />
    <long name="VideoResumeTime" value="-1" />
    <int name="ml_scan" value="1" />
    <int name="fragment_id" value="2131362810" />
    <boolean name="video_player_tips_shown" value="true" />
    <int name="audio_stop_after" value="-1" />
    <int name="video_hud_timeout_in_s" value="2" />
    <boolean name="enable_double_tap_seek" value="false" />
    <boolean name="enable_seek_buttons" value="false" />
    <boolean name="enable_volume_gesture" value="false" />
    <boolean name="enable_brightness_gesture" value="false" />
</map>
"@

try {
    $client = New-Object System.Net.Sockets.TcpClient
    $client.Connect("192.168.100.6", 5555)
    $stream = $client.GetStream()
    $stream.ReadTimeout = 8000

    function Write-AdbMsg($cmd, $a0, $a1, [byte[]]$data) {
        $sum = 0
        if ($data) { foreach ($b in $data) { $sum += [int]$b -band 0xFF } }
        $len = if ($data) { $data.Length } else { 0 }
        $magic = ($cmd -bxor 0xFFFFFFFF)
        $hdr = New-Object byte[] 24
        [System.BitConverter]::GetBytes([int]$cmd).CopyTo($hdr, 0)
        [System.BitConverter]::GetBytes([int]$a0).CopyTo($hdr, 4)
        [System.BitConverter]::GetBytes([int]$a1).CopyTo($hdr, 8)
        [System.BitConverter]::GetBytes([int]$len).CopyTo($hdr, 12)
        [System.BitConverter]::GetBytes([int]$sum).CopyTo($hdr, 16)
        [System.BitConverter]::GetBytes([int]$magic).CopyTo($hdr, 20)
        $stream.Write($hdr, 0, 24)
        if ($len -gt 0) { $stream.Write($data, 0, $len) }
        $stream.Flush()
    }

    function Read-AdbMsg() {
        $hdr = New-Object byte[] 24
        $r = 0
        while ($r -lt 24) {
            $n = $stream.Read($hdr, $r, 24 - $r)
            if ($n -le 0) { break }
            $r += $n
        }
        if ($r -lt 24) { return $null }
        $cmd = [System.BitConverter]::ToInt32($hdr, 0)
        $a0 = [System.BitConverter]::ToInt32($hdr, 4)
        $a1 = [System.BitConverter]::ToInt32($hdr, 8)
        $len = [System.BitConverter]::ToInt32($hdr, 12)
        $data = New-Object byte[] $len
        $dr = 0
        while ($dr -lt $len) {
            $n = $stream.Read($data, $dr, $len - $dr)
            if ($n -le 0) { break }
            $dr += $n
        }
        return @{ Cmd = $cmd; Arg0 = $a0; Arg1 = $a1; Data = $data }
    }

    $cnxn = [System.Text.Encoding]::UTF8.GetBytes("host::`0")
    Write-AdbMsg 0x4e584e43 0x01000000 4096 $cnxn
    $resp = Read-AdbMsg

    $cmdCat = "shell:cat > /sdcard/vlc_prefs_new.xml`0"
    Write-AdbMsg 0x4e45504f 1 0 ([System.Text.Encoding]::UTF8.GetBytes($cmdCat))
    $openResp = Read-AdbMsg
    $remoteId = $openResp.Arg0

    # Пишем байты XML
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($xmlContent)
    Write-AdbMsg 0x45545257 1 $remoteId $bytes
    $respWrte = Read-AdbMsg

    # Закрываем поток cat
    Write-AdbMsg 0x45534c43 1 $remoteId $null
    Start-Sleep -Milliseconds 300

    # Теперь копируем файл на место
    $cmdCp = "shell:su 10026 cp /sdcard/vlc_prefs_new.xml /data/data/org.videolan.vlc/shared_prefs/org.videolan.vlc_preferences.xml`0"
    Write-AdbMsg 0x4e45504f 2 0 ([System.Text.Encoding]::UTF8.GetBytes($cmdCp))
    $openCp = Read-AdbMsg
    $remoteIdCp = $openCp.Arg0
    while ($true) {
        $msg = Read-AdbMsg; if (-not $msg) { break }
        if ($msg.Cmd -eq 0x45545257) { Write-AdbMsg 0x59414b4f 2 $remoteIdCp $null }
        elseif ($msg.Cmd -eq 0x45534c43) { break }
    }

    $client.Close()
    Write-Output "XML_APPLIED_DIRECTLY"
} catch {
    Write-Error $_.Exception.Message
}
